package edu.is2024.rh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RhApplicationTests {

	@Test
	void contextLoads() {
	}

}
